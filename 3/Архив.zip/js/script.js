$(document).ready(function() {
    $(".slider").owlCarousel({
        loop: true,
        nav: true,
        dots: true,
        dotsEach: false,
        items: 2,
        margin: 0,
        autoHeight: false,
        autoplay: true,
        autoplayTimeout: 5000,
        autoplayHoverPause: true,
        // responsive:{
        // 	0: {
                
        // 	},
        // 	1025: {
                
        // 	}
        // }
    });
})

